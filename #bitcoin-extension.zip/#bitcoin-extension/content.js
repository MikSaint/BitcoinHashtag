// Created by @oneSaint on July 26, 2024

function insertBitcoinSVG() {
    console.log('Scanning for #Bitcoin tags...');
    document.querySelectorAll('span').forEach(span => {
        // Improved check to see if the SVG has been added
        if (span.textContent.includes('#Bitcoin') && !span.querySelector('img')) {
            console.log('Processing hashtag:', span.textContent);

            const bitcoinLogo = document.createElement('img');
            bitcoinLogo.src = chrome.runtime.getURL("bitcoin.svg");
            bitcoinLogo.style.height = '1em';
            bitcoinLogo.style.width = 'auto';
            bitcoinLogo.style.marginLeft = '0.15em'; // Space between text and image
            // bitcoinLogo.style.verticalAlign = 'bottom'; // Adjust vertical alignment to lower the image
            bitcoinLogo.style.position = 'relative'; // Make position relative for fine tuning
            bitcoinLogo.style.bottom = '-2px'; // Lower the image slightly below the baseline of the text

            span.appendChild(bitcoinLogo);
        }
    });
}

// Debounce function to limit how often a function can fire
const debounce = (func, delay) => {
    let inDebounce;
    return function() {
        const context = this;
        const args = arguments;
        clearTimeout(inDebounce);
        inDebounce = setTimeout(() => func.apply(context, args), delay);
    }
}

const debouncedInsert = debounce(insertBitcoinSVG, 500);

const observer = new MutationObserver(mutations => {
    console.log('DOM mutation observed');
    debouncedInsert();
});

// Set up the observer on a stable element, typically the body or a main container
const bodyElement = document.body;

if (bodyElement) {
    observer.observe(bodyElement, {
        childList: true,
        subtree: true
    });
} else {
    console.error('Failed to find a valid element for MutationObserver.');
}

// Initial scan on page load
debouncedInsert();
console.log('Bitcoin extension initialized.');